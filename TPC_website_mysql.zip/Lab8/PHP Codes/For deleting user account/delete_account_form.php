<!DOCTYPE html>
<html>
<head>
     <title>Delete Account</title>
</head>
<body>
<h1>Delete Account</h1>
<form action="delete_account.php" method="POST">
<label for="email">Email:</label>
<input type="email" name="email" required><br><br>
<label for="password">Password:</label>
<input type="password" name="password" required><br><br>
<button type="submit">Delete Account</button>
</form>       
</body>
</html>